class Config {
  String url = 'https://app.infinityrobot.net/';
  String url2 = 'app.infinityrobot.net';

  // String url = 'https://bosco.greatwallsolution.com/';
  // String url2 = 'bosco.greatwallsolution.com';
}